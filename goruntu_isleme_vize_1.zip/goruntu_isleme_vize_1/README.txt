					*** Proje İşlevi ***
Başparmak ile işaret parmak arasındaki mesafeye bağlı olarak bilgisayar ekranının parlaklığını ayarlama.

				  *** Projeyi Kullanma Yöntemi ***

-1- Dosyayı zipten çıkarıp belgelere atınız.

-2- Visual Studio Cod'u açıp "file" kategorisinden "open folder" seçeneğine tıklayıp "goruntu_isleme_vize_1" klasörünü seçiniz.

-3- Terminale "pip install screen-brightness-control" yazıp "Enter"a basınız. (Sizde mediapipe modülünün zaten var olduğunu varsayıyorum.)

-4- Kod kullanıma hazır. (İşlemi sonlandırmak için "q" tuşuna basınız.)